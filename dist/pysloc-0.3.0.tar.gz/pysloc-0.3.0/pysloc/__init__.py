# merkletree/__init__.py

from abc import ABCMeta, abstractmethod, abstractproperty
import binascii, hashlib, os, re
from stat import *

__all__ = [ '__version__',      '__version_date__', 
            'countLinesInDir',  'countLinesInFile',
          ]

__version__      = '0.3.0'
__version_date__ = '2015-02-16'

TQUOTE = '"""'

def countLinesInFile(pathToFile, verbose):
    inTripleQuote         = False
    linesSoFar, slocSoFar = (0,0)
    with open(pathToFile, 'r') as f:
        line = f.readline()
        while line:
            if inTripleQuote:
                if line is None:
                    break
                # we always count this line
                linesSoFar += 1
                slocSoFar  += 1
                count = line.count(TQUOTE)
                if count % 2 :
                    inTripleQuote = False
            else:
                if line is None or line == '':
                    break
                linesSoFar += 1
                s = line.partition('#')[0]      # strip off comments
                line = s.strip()                # strip off leading, trailing
                if line != '':
                    slocSoFar += 1
                count = line.count(TQUOTE)
                if count % 2:
                    inTripleQuote = True
            line = f.readline()
    if verbose:
        print ("%-25s: %5d lines, %5d sloc" % (
                pathToFile, linesSoFar, slocSoFar))
    return (linesSoFar, slocSoFar)


def countLinesInDir(pathToDir, options):
    exRE        = options['exRE']
    verbose     = options['verbose']
    lines, sloc = (0,0)
    files = os.listdir(pathToDir)
    if files:
        for file in sorted(files):
            # consider exclusions ...
            if exRE is not None and exRE.search(file) is not None:
                continue
            pathToFile = os.path.join(pathToDir, file)
            s = os.lstat(pathToFile)        # ignores symlinks
            mode = s.st_mode
            if S_ISDIR(mode):
                (moreLines, moreSloc) = countLinesInDir(pathToFile, options)
                lines += moreLines
                sloc  += moreSloc
            elif S_ISREG(mode):
                if file.endswith('.py'):
                    (moreLines, moreSloc) =  \
                                        countLinesInFile(pathToFile, verbose)
                    lines += moreLines
                    sloc  += moreSloc
    return (lines, sloc)
